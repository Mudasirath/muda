<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Créer une Partie du Corps') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    @if ($errors->any())
                        <div class="alert alert-error mb-4">
                            <span>Merci de corriger les erreurs ci-dessous.</span>
                        </div>
                    @endif

                    <form action="{{ route('partie_du_corps.store') }}" method="POST" enctype="multipart/form-data" class="space-y-4">
                        @csrf

                        <div>
                            <label for="nom" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Nom</label>
                            <input type="text" name="nom" id="nom" value="{{ old('nom') }}" class="input input-bordered w-full" required>
                            @error('nom')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div>
                            <label for="image" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Image</label>
                            <input type="file" name="image" id="image" class="file-input file-input-bordered w-full" accept="image/*" onchange="previewImage(event)">
                            @error('image')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                            <div id="image-preview" class="mt-4 hidden">
                                <img id="preview-img" src="" alt="Aperçu de l'image" class="w-32 h-32 object-cover rounded">
                            </div>
                        </div>

                        <div>
                            <label for="francais" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Français</label>
                            <input type="text" name="francais" id="francais" value="{{ old('francais') }}" class="input input-bordered w-full" required>
                            @error('francais')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div>
                            <label for="goun" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Goun</label>
                            <input type="text" name="goun" id="goun" value="{{ old('goun') }}" class="input input-bordered w-full" required>
                            @error('goun')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div>
                            <label for="fon" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Fon</label>
                            <input type="text" name="fon" id="fon" value="{{ old('fon') }}" class="input input-bordered w-full" required>
                            @error('fon')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div>
                            <label for="yoruba" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Yoruba</label>
                            <input type="text" name="yoruba" id="yoruba" value="{{ old('yoruba') }}" class="input input-bordered w-full" required>
                            @error('yoruba')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div>
                            <label for="dendi" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Dendi</label>
                            <input type="text" name="dendi" id="dendi" value="{{ old('dendi') }}" class="input input-bordered w-full" required>
                            @error('dendi')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div>
                            <label for="anglais" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Anglais</label>
                            <input type="text" name="anglais" id="anglais" value="{{ old('anglais') }}" class="input input-bordered w-full" required>
                            @error('anglais')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="flex justify-end gap-2">
                            <a href="{{ route('partie_du_corps.index') }}" class="btn btn-secondary">Annuler</a>
                            <button type="submit" class="btn btn-primary">Enregistrer</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        function previewImage(event) {
            const file = event.target.files[0];
            const preview = document.getElementById('image-preview');
            const previewImg = document.getElementById('preview-img');

            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewImg.src = e.target.result;
                    preview.classList.remove('hidden');
                };
                reader.readAsDataURL(file);
            } else {
                preview.classList.add('hidden');
            }
        }
    </script>
</x-app-layout>
